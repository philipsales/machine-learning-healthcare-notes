# Contributing

When contributing to this repository, please first discuss the change you wish to make via issue,
email, or any other method with the owners of this repository before making a change. 
This project adheres to the [Contributor Covenant Code of Conduct](http://contributor-covenant.org/). 

# Maintainers

NegBio is maintained with :heart: by:

-- **@yfpeng**

See also the list of [contributors](https://github.com/ncbi-nlp/NegBio/contributors) who participated in this project.
